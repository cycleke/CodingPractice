fil = raw_input();
print(len(open(fil, 'r').read().split()));
